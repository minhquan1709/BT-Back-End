﻿namespace LAB2.Models;
public class Todo
{
    public int Id { get; set; }
    public string Task { get; set; }
}
